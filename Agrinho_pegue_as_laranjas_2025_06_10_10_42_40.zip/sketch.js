let items = [];
let score = 0;

function setup() {
  createCanvas(800,800);
  // Cria alguns itens para serem colhidos
  for (let i = 0; i < 10; i++) {
    items.push({
      x: random(width),
      y: random(-100, 0),
      size: 20,
      speed: random(1, 3),
      collected: false
    });
  }
}

function draw() {
  background(200, 255, 200); // Cor de fundo que lembra o campo

  // Desenha a cesta controlada pelo mouse
  fill(139, 69, 19);
  rect(mouseX - 20, height - 30, 40, 20);

  // Atualiza e desenha os itens
  for (let item of items) {
    if (!item.collected) {
      item.y += item.speed;
      if (item.y > height) {
        item.y = random(-100, 0);
        item.x = random(width);
      }
      // Desenha o item
      fill(255, 215, 0);
      ellipse(item.x, item.y, item.size);
    }
  }

  // Verifica colisões ao pressionar A
  if (keyIsDown(65)) { // 65 é o código da tecla A
    for (let item of items) {
      if (!item.collected && abs(item.x - mouseX) < 20 && abs(item.y - (height - 20)) < 20) {
        item.collected = true;
        score++;
      }
    }
  }

  // Exibe a pontuação
  fill(0);
  textSize(16);
  text("Colhidas: " + score, 10, 20);
    // Exibe a pontuação
 fill(10);
  textSize(16);
  text('Pressione "A" para pegar as laranjas', 10, 50);
  fill(10);
  textSize(21);
  text('Pegue as laranjas!', 200, 100);
}